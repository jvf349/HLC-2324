package com.example.teoriadeservicios;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

// Broadcast receiver que recibe las emisiones desde los servicios
public class ResponseReceiver extends BroadcastReceiver {

    // Sin instancias
    public ResponseReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        switch (intent.getAction()) {
            case Constants.ARRANCAMOS_BACKGROUND_SERVICE:
                Toast.makeText(context,"Arrancando Background Service", Toast.LENGTH_LONG).show();
                break;

            case Constants.PARANDO_BACKGROUND_SERVICE:
                Toast.makeText(context,"Parando Background Service", Toast.LENGTH_LONG).show();
                break;

            case Constants.ARRANCAMOS_FOREGROUND_SERVICE:
                Toast.makeText(context,"Arrancando Foreground Service", Toast.LENGTH_LONG).show();
                break;

            case Constants.PARANDO_FOREGROUND_SERVICE:
                Toast.makeText(context,"Parando Foreground Service", Toast.LENGTH_LONG).show();
                break;
        }
    }
}
