package com.example.teoriadeservicios;

import android.app.IntentService;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;



public class IntentServiceHLC extends IntentService {

    private boolean hiloTrabajando=true;

    public IntentServiceHLC() {
        super("IntentServiceHLC");
    }

    //Le he puesto un temporizador para que a los 10 segundos se autodestruya.
    //Fijaros que el IntentService no necesita la creación de hilos. Se supone que lo que ejecuta ya lo hace
    //en un hilo diferente
    @Override
    protected void onHandleIntent( Intent intent) {

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.e("Servicio", "Servicio Intent está parando...");
                hiloTrabajando=false;
                stopSelf();
            }
        }, 10000);


        while (hiloTrabajando) {
            Log.e("Servicio", "Servicio Intent está corriendo...");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
