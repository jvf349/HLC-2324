package com.example.teoriadeservicios;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


//Buenas chicos, la implementación de este servicio Foreground es buena, pero,
//si probáis a pararlo y volverlo a arrancar, algunas veces crashea. He estado buscando solución
//y lo único que he podido leer es que el sistema Android no está habilitado para arrancar y parar
//este tipo de servicios de una forma rápida. No sé.
//Bueno, fijaros cómo gracias a Intent, puedo saber si lo que quiero es arrancarlo o pararlo.

public class ForegroundService extends Service {

    private boolean hiloTrabajando=true;
    private int numeroServicio=-1;
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent.getAction().equals(Constants.ARRANCAMOS_FOREGROUND_SERVICE)) {
            hiloTrabajando=true;
            // your start service code
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (hiloTrabajando) {
                        Log.e("Servicio", "Servicio Foreground está corriendo...");
                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();

            //Mandamos un mensajito al MainActivity via Intent.
            Intent localIntent = new Intent(Constants.ARRANCAMOS_FOREGROUND_SERVICE);
            LocalBroadcastManager.getInstance(ForegroundService.this).sendBroadcast(localIntent);

            numeroServicio=startId; // Ojo! Necesitamos almacenar el id del servicio iniciado para luego poder pararlo.
        }
        else if (intent.getAction().equals( Constants.PARANDO_FOREGROUND_SERVICE)) {
            hiloTrabajando=false;
            stopForeground(true);
            stopSelf(numeroServicio);
            Log.e("Servicio","Servicio Foreground se ha parado...");

            //Mandamos un mensajito al MainActivity via Intent.
            Intent localIntent = new Intent(Constants.PARANDO_FOREGROUND_SERVICE);
            LocalBroadcastManager.getInstance(ForegroundService.this).sendBroadcast(localIntent);
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
