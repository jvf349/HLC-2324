package com.example.teoriadeservicios;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class BackgroundService extends Service {

    private boolean hiloTrabajando=true;
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                while(hiloTrabajando){
                    Log.e("Servicio","Servicio Background está corriendo...");
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

        //Mandamos un mensajito al MainActivity via Intent.
        Intent localIntent = new Intent(Constants.ARRANCAMOS_BACKGROUND_SERVICE);
        LocalBroadcastManager.getInstance(BackgroundService.this).sendBroadcast(localIntent);

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        Log.e("Servicio","Servicio Background se ha parado...");
        hiloTrabajando=false;

        Intent localIntent = new Intent(Constants.PARANDO_BACKGROUND_SERVICE);
        LocalBroadcastManager.getInstance(BackgroundService.this).sendBroadcast(localIntent);

        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
