package com.example.teoriadeservicios;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button backgroundServiceBtn;
    private Button stopBackgroundServiceBtn;
    private Button foregroundServiceBtn;
    private Button stopForegroundServiceBtn;
    private Button intentServiceBtn;
    private Button stopIntentServiceBtn;
    private Button mandarNotificacionBtn;

    private ResponseReceiver receiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        backgroundServiceBtn = (Button) findViewById(R.id.background_button);
        stopBackgroundServiceBtn=(Button) findViewById(R.id.stop_background_button);

        foregroundServiceBtn = (Button) findViewById(R.id.foreground_button);
        stopForegroundServiceBtn = (Button) findViewById(R.id.stop_foreground_button);

        intentServiceBtn = (Button) findViewById(R.id.intent_button);
        stopIntentServiceBtn=(Button) findViewById(R.id.stop_intent_button);

        mandarNotificacionBtn = (Button) findViewById(R.id.notificaction_button);

        //Background Service
        backgroundServiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this , BackgroundService.class);
                startService(intent);
            }
        });

        stopBackgroundServiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this , BackgroundService.class);
                stopService(intent);
            }
        });

        //Foreground Service
        foregroundServiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this , ForegroundService.class);
                intent.setAction(Constants.ARRANCAMOS_FOREGROUND_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent);
                }
            }
        });

        stopForegroundServiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this , ForegroundService.class);
                intent.setAction(Constants.PARANDO_FOREGROUND_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent);
                }
            }
        });


        //Intent Service
        intentServiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent( view.getContext(), IntentServiceHLC.class);
                    startService(intent);
            }
        });

        stopIntentServiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent stopIntent = new Intent(MainActivity.this, IntentServiceHLC.class);
                stopIntent.setAction(Constants.PARANDO_INTENT_SERVICE);
                stopService(stopIntent);
            }
        });

        mandarNotificacionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int reqCode = 1;
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                showNotification(v.getContext(), "Title", "This is the message to display", intent, reqCode);
            }
        });


        //Activamos el BradcastReceiver:
        // Filtro de acciones que serán alertadas
        IntentFilter filter = new IntentFilter();
        filter.addAction(Constants.ARRANCAMOS_BACKGROUND_SERVICE);
        filter.addAction(Constants.PARANDO_BACKGROUND_SERVICE);
        filter.addAction(Constants.ARRANCAMOS_FOREGROUND_SERVICE);
        filter.addAction(Constants.PARANDO_FOREGROUND_SERVICE);
        filter.addAction(Constants.ARRANCAMOS_INTENT_SERVICE);
        filter.addAction(Constants.PARANDO_INTENT_SERVICE);

        // Crear un nuevo ResponseReceiver
        receiver = new ResponseReceiver();

        // Registrar el receiver y su filtro
        LocalBroadcastManager.getInstance(this).registerReceiver( receiver, filter);
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        super.onDestroy();
    }

    //Comprobar que el servicio está ya corriendo
    public boolean servicioForegroundCorriendo() {
        ActivityManager manager= (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for(ActivityManager.RunningServiceInfo service: manager.getRunningServices(Integer.MAX_VALUE))
        {
            if(ForegroundService.class.getName().equals(service.service.getClassName()))
            {
                return true;
            }
        }
        return false;
    }

    //Genera una notificación (Push Notification)
    public void showNotification(Context context, String title, String message, Intent intent, int reqCode) {

        PendingIntent pendingIntent = PendingIntent.getActivity(context, reqCode, intent, PendingIntent.FLAG_ONE_SHOT);
        String CHANNEL_ID = "channel_name";// The id of the channel.
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channel Name";// The user-visible name of the channel.
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            notificationManager.createNotificationChannel(mChannel);
        }
        notificationManager.notify(reqCode, notificationBuilder.build()); // 0 is the request code, it should be unique id
    }
}