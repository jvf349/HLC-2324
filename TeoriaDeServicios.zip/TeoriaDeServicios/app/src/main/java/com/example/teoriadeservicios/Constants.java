package com.example.teoriadeservicios;

/**
 * Contiene las constantes de las acciones de los servicios y sus parámetros
 */
public class Constants {
    /**
     * Constantes para {@link BackgroundService}
     */
    public static final String ARRANCAMOS_BACKGROUND_SERVICE = "com.example.teoriadeservicios.action.ARRANCANDO_BACKGROUND";
    public static final String PARANDO_BACKGROUND_SERVICE = "com.example.teoriadeservicios.action.PARANDO_BACKGROUND";

    /**
     * Constantes para {@link ForegroundService}
     */
    public static final String ARRANCAMOS_FOREGROUND_SERVICE = "com.example.teoriadeservicios.action.ARRANCANDO_FOREGROUND";
    public static final String PARANDO_FOREGROUND_SERVICE = "com.example.teoriadeservicios.action.PARANDO_FOREGROUND";

    /**
     * Constantes para {@link IntentServiceHLC}
     */
    public static final String ARRANCAMOS_INTENT_SERVICE = "com.example.teoriadeservicios.action.ARRANCANDO_INTENT";
    public static final String PARANDO_INTENT_SERVICE = "com.example.teoriadeservicios.action.PARANDO_INTENT";


}